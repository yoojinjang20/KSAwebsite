import React from 'react';
import './NavBar.css'
import logo from './navbar-logo.png';

console.log(logo);

const Sidebar = () => {
    return(
        <>
        <button>Click</button>
        <div>
            <div>
                <img src={logo} alt="logo"/>
            </div>
            <ul>
                <li>
                    
                </li>
            </ul>
        </div>
        </>

    )
}

export default NavBar;

