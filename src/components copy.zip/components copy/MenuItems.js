export const MenuItems = [
    {
        title: 'Home',
        url:'/Home',
        cName: 'nav-links'
    },
    {
        title: 'About Us',
        url:'#',
        cName: 'nav-links'
 
     },
     {
        title: 'Activities / Clubs',
        url:'#',
        cName: 'nav-links'
 
     },
     {
        title: 'Information',
        url:'#',
        cName: 'nav-links'
 
     },
     {
        title: 'Sponsorships',
        url:'#',
        cName: 'nav-links'
 
     },
     {
        title: 'Login / Sign Up',
        url:'#',
        cName: 'nav-links'
 
     },
     {
        title: 'Contact Us',
        url:'#',
        cName: 'nav-links'
 
     }
];